from django.apps import AppConfig


class JueqConfig(AppConfig):
    name = 'JuEq'
