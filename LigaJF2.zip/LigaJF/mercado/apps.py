from django.apps import AppConfig


class MercadoConfig(AppConfig):
    name = 'mercado'
