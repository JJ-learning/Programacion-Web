from django.apps import AppConfig


class CajoConfig(AppConfig):
    name = 'CaJo'
